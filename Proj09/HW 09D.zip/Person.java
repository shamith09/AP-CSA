/**
 * Write a description of class Person here.
 *
 * @author Bhavya Gupta
 * @version 11/19/19
 */
public class Person
{
    private String fullName;
    private String emailAddrs;
    private double cashAmt;
    private BankAccount bankAcct;
    
    public Person(String n)
    {
        fullName = n;
    }
    public Person(String personName, String emailAdd, double cash)
    {
        fullName = personName;
        emailAddrs = emailAdd;
        cashAmt = cash;
    }
    
    public void openBankAcct()
    {
        bankAcct = new BankAccount();
    }
    public void transferToBankAcct(double amt)
    {
        cashAmt -= amt;
        bankAcct.deposit(amt);
    }
    public String toString()
    {
        return "Name: " + fullName + ", Email Address: " + emailAddrs +
                ", Cash: " + cashAmt + ", Bank Balance: " + 
                bankAcct.getBalance();
    }
    public String getName()
    {
        return fullName;
    }
    public String getEmail()
    {
        return emailAddrs;
    }
    public double getAmt()
    {
        return cashAmt;
    }
    public void setEmail(String e)
    {
        emailAddrs = e;
    }
    public void addCash(double a)
    {
        cashAmt += a;
    }
    public double getMoneyAmt()
    {
        return cashAmt + bankAcct.getBalance();
    }
    
    public static void main(String[] args)
    {
        Person p1 = new Person("Bob");
        Person p2 = new Person("John", "john@gmail.com", 50);
        System.out.println(p1.getName());
        System.out.println(p2.getName());
        System.out.println(p2.getEmail());
        p2.addCash(0.44);
        System.out.println(p2.getName());
        p2.setEmail("jcmc@yahoo.edu");
        System.out.println(p2.getAmt());
        p2.openBankAcct();
        p2.transferToBankAcct(15.0);
        System.out.println(p2);
        p2.bankAcct.withdraw(500.0);
        System.out.println(p2.getMoneyAmt());
    }
}