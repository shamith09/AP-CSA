
/**
 * Write a description of class StringChecker here.
 *
 * @Bhavya Gupta
 * @09/09/2019
 */

public class StringChecker
{
    public static void main(String[] args)
    {
        String state = "California";
        
        System.out.println("Original: " + state);
        System.out.println("Result: " + state.replace("i", "!"));
        System.out.println("Expected: Cal!forn!a");
    }
}
