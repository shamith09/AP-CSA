
/**
* Write a description of class BankAcct here.
*
* @author (Bhavya Gupta)
* @version (09/17/19)
*/
public class BankAcct
{
    /**
    * Lets users create a bank acc with an initial balance
    * Users can withdraw, deposit, check balance, or add interest
    * Users CANNOT access the variable balance itself
    */
        
    // FIELDS
    private double balance;
    
    // CONSTRUCTORS
    public BankAcct(double initBal) {
        balance = initBal;
    }
    
    public BankAcct() {
        balance = 0;
    }
    
    // METHODS
    public void deposit(double amt) {
        /**
         * deposits $amt in to the account
         */
        balance += amt;
    }
    
    public void withdraw(double amt) {
        /**
         * withdraws $amt in to the account
         */
        balance -= amt;
    }
    
    public double getBalance() {
        /**
         * returns the amount in the account in $
         */
        return balance;
    }
    
    public void addInterest(double rate) {
        /**
         * adds rate*100% interest to the account 
         * Ex: rate of .05 is 5% interest
         */
        balance *= rate + 1;
    }
}
