
/**
 * Write a description of class Swapper here.
 *
 * @Bhavya Gupta
 * @09/09/2019
 */


public class Swapper
{
    public static void main(String[] args)
    {
        String school = "Cal High";
        
        System.out.println("Original: " + school);
        System.out.println("Result: " + school.replace ("i", "a").replaceFirst("a", "i"));        
        System.out.println("Expected: Cil Hagh");
    }
}
