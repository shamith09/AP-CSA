
/**
 * 
 *
 * @Bhavya Gupta
 * @08/28/2019
 */
public class PrintFace
{
    public static void main(String[] args)
    {
        System.out.println("    XXXXX");
        System.out.println("   X     X");
        System.out.println(" ((  o o  ))");
        System.out.println("   |  V  |");
        System.out.println("   | === |");
        System.out.println("    -----");
    }
}
