
/**
 * 
 *
 * @Bhavya Gupta
 * @08/28/2019
 */
public class PrintInitials
{
    public static void main(String[] args)
    {
        System.out.println("XXX     XXX");
        System.out.println("X  XX  X   X");
        System.out.println("X  X   X");
        System.out.println("XXX    X");
        System.out.println("X  X   X     XX");
        System.out.println("X   X  X    XXX");
        System.out.println("XXXX     XXXX X");
    }
}
